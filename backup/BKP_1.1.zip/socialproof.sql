/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.2.2-MariaDB, for Android (aarch64)
--
-- Host: 127.0.0.1    Database: socialproof
-- ------------------------------------------------------
-- Server version	5.7.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `archetypes`
--

DROP TABLE IF EXISTS `archetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `archetypes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `speaking_style` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vocabulary_examples` text COLLATE utf8mb4_unicode_ci,
  `typo_rate` tinyint(4) DEFAULT '10',
  `emoji_rate` tinyint(4) DEFAULT '20',
  `response_delay_min` int(11) DEFAULT '3',
  `response_delay_max` int(11) DEFAULT '25',
  `avatar_seed` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `archetypes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `archetypes` WRITE;
/*!40000 ALTER TABLE `archetypes` DISABLE KEYS */;
INSERT INTO `archetypes` VALUES
(1,'Mae de Familia','Mulher de 35-50 anos, pratica, carinhosa','Fala de forma carinhosa e pratica. Usa gente, meninas. Conta experiencias reais com filhos e marido.','Gente, to adorando! / meninas me ajudem / fiz pra toda familia',15,35,5,30,'mae1','2026-03-01 13:29:07'),
(2,'Nerd Fitness','Homem de 25-35 anos, obcecado com dados e macros','Fala com precisao cientifica. Cita estudos. Gosta de numeros e percentuais.','De acordo com um estudo / meu percentual de gordura / a ciencia mostra que',5,10,8,40,'nerd1','2026-03-01 13:29:07'),
(3,'Mano da Quebrada','Jovem de 18-28 anos, girias, informal, entusiasmado','Usa mano, cara, demais. Frases curtas. Muitos pontos de exclamacao.','mano que resultado!! / cara to chocado / funcionou demais',25,45,2,15,'mano1','2026-03-01 13:29:07'),
(4,'Nutricionista','Profissional da saude, 30-45 anos, didatica','Linguagem tecnica mas acessivel. Cuida para nao dar diagnostico.','Do ponto de vista nutricional / as evidencias indicam / consulte um profissional',3,15,10,45,'nutri1','2026-03-01 13:29:07'),
(5,'Vendedor de Rua','Pessoa animada, persuasiva, 28-45 anos','Entusiasta, muitas exclamacoes. Sempre descobriu o segredo de algo.','Descobri o segredo! / vale demais a pena / to te contando isso porque',20,40,3,20,'vend1','2026-03-01 13:29:07'),
(6,'Advogado','Profissional exigente, cetico, 35-50 anos','Questiona antes de aceitar. Analitico. Usa todavia, entretanto, cabe ressaltar.','Quais sao as evidencias? / cabe ressaltar que / todavia os resultados mostram',5,5,15,60,'adv1','2026-03-01 13:29:07');
/*!40000 ALTER TABLE `archetypes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocks` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','running','paused','done') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `start_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `loop_infinite` tinyint(4) DEFAULT '0',
  `is_tips_block` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-02 23:28:58
