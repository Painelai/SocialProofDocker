<?php
// ============================================================
// engine.php — Motor de execução das timelines
// Compatível com schema: archetype_id + name_pool + room_messages v2
// ============================================================

require_once __DIR__ . '/config.php';

class ChatEngine {

    private static array $assignedNames = [];

    public static function tick(): array {
        $posted = [];
        $rooms  = DB::fetchAll("SELECT id FROM rooms WHERE status = 'active'");
        foreach ($rooms as $room) {
            $msgs   = self::processRoom($room['id']);
            $posted = array_merge($posted, $msgs);
        }
        return $posted;
    }

    public static function processRoom(int $roomId): array {
        $posted = [];
        self::startPendingBlocks($roomId);
        $blocks = DB::fetchAll(
            "SELECT * FROM blocks WHERE room_id = ? AND status = 'running' ORDER BY id ASC",
            [$roomId]
        );
        foreach ($blocks as $block) {
            $msgs   = self::processBlock($block, $roomId);
            $posted = array_merge($posted, $msgs);
        }
        return $posted;
    }

    private static function processBlock(array $block, int $roomId): array {
        $posted = [];
        $now    = time();

        $lastPosted = DB::fetch(
            'SELECT posted_at FROM timeline_messages
             WHERE block_id = ? AND posted_at IS NOT NULL
             ORDER BY sequence_order DESC LIMIT 1',
            [$block['id']]
        );

        $next = DB::fetch(
            'SELECT tm.*,
                    a.name       as archetype_name,
                    a.avatar_seed as archetype_seed
             FROM timeline_messages tm
             LEFT JOIN archetypes a ON a.id = tm.archetype_id
             WHERE tm.block_id = ? AND tm.posted_at IS NULL
             ORDER BY tm.sequence_order ASC LIMIT 1',
            [$block['id']]
        );

        if (!$next) {
            if (!empty($block['loop_infinite'])) {
                DB::query('UPDATE timeline_messages SET posted_at = NULL WHERE block_id = ?', [$block['id']]);
                DB::query('DELETE FROM room_messages WHERE block_id = ?', [$block['id']]);
                DB::query("UPDATE blocks SET status = 'running' WHERE id = ?", [$block['id']]);
                unset(self::$assignedNames[$block['id']]);
            } else {
                DB::query("UPDATE blocks SET status = 'done' WHERE id = ?", [$block['id']]);
            }
            return $posted;
        }

        if ($lastPosted) {
            $baseDelay = (int)$next['delay_after_prev'];
            // Dicas (tip) têm delay aleatório entre 30s e 120s para parecer mais natural
            if ($next['message_type'] === 'tip') {
                $baseDelay = rand(30, 120);
            }
            $canPostAt = strtotime($lastPosted['posted_at']) + $baseDelay;
        } else {
            $canPostAt = $now;
        }

        if ($now < $canPostAt) {
            return $posted;
        }

        [$displayName, $avatarUrl, $avatarSeed, $resolvedArchetypeId] = self::resolveAuthor($next, $block['id']);

        // Bloco de Dicas: força message_type=tip e archetype Nutricionista (id=4)
        $finalMessageType = $next['message_type'];
        if (!empty($block['is_tips_block'])) {
            $finalMessageType = 'tip';
            [$displayName, $avatarUrl, $avatarSeed, $resolvedArchetypeId] = self::resolveAuthor(
                array_merge($next, ['archetype_id' => 4, 'bot_id' => null, 'resolved_name' => null]),
                $block['id']
            );
        } elseif ($next['message_type'] === 'tip') {
            // Dicas avulsas (fora de bloco de dicas) também forçam Nutricionista
            [$displayName, $avatarUrl, $avatarSeed, $resolvedArchetypeId] = self::resolveAuthor(
                array_merge($next, ['archetype_id' => 4, 'bot_id' => null, 'resolved_name' => null]),
                $block['id']
            );
        }

        $replyToRoomId = null;
        if ($next['reply_to_id']) {
            $mapped = DB::fetch(
                'SELECT rm.id FROM room_messages rm
                 JOIN timeline_messages tm ON tm.id = rm.timeline_message_id
                 WHERE tm.id = ? AND rm.room_id = ?',
                [$next['reply_to_id'], $roomId]
            );
            $replyToRoomId = $mapped ? $mapped['id'] : null;
        }

        $roomMsgId = DB::insert(
            'INSERT INTO room_messages
             (room_id, block_id, timeline_message_id, bot_id, archetype_id, display_name, avatar_url, avatar_seed, content, message_type, reply_to_room_msg_id)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            [
                $roomId,
                $block['id'],
                $next['id'],
                $next['bot_id'] ?? null,
                $resolvedArchetypeId,
                $displayName,
                $avatarUrl,
                $avatarSeed,
                $next['content'],
                $finalMessageType,
                $replyToRoomId,
            ]
        );

        DB::query('UPDATE timeline_messages SET posted_at = NOW() WHERE id = ?', [$next['id']]);

        $posted[] = [
            'room_msg_id' => $roomMsgId,
            'block_id'    => $block['id'],
            'bot_name'    => $displayName,
            'content'     => $next['content'],
            'type'        => $finalMessageType,
        ];

        return $posted;
    }

    private static function resolveAuthor(array $msg, int $blockId): array {
        // Modo clássico: bot_id fixo
        if (!empty($msg['bot_id'])) {
            $bot = DB::fetch('SELECT name, avatar_url, archetype_id FROM bots WHERE id = ?', [$msg['bot_id']]);
            if ($bot) {
                $seed = $bot['name'];
                $url  = $bot['avatar_url'] ?: avatarUrl($seed);
                return [$bot['name'], $url, $seed, $bot['archetype_id']];
            }
        }

        $archetypeId = (int)($msg['archetype_id'] ?? 0);

        if ($archetypeId) {
            // Se tem resolved_name pré-definido, usa ele
            if (!empty($msg['resolved_name'])) {
                $seed = $msg['resolved_name'] . $archetypeId;
                return [$msg['resolved_name'], avatarUrl($seed), $seed, $archetypeId];
            }

            // Sorteia do name_pool evitando repetição no bloco
            $used      = self::$assignedNames[$blockId] ?? [];
            $pool      = DB::fetchAll(
                'SELECT first_name, abbreviation FROM name_pool WHERE archetype_id = ? AND active = 1',
                [$archetypeId]
            );
            $available = array_values(array_filter($pool, fn($p) => !in_array($p['first_name'], $used)));

            if (empty($available)) {
                self::$assignedNames[$blockId] = [];
                $available = $pool;
            }

            if (!empty($available)) {
                $pick        = $available[array_rand($available)];
                $displayName = $pick['first_name'] . ' ' . $pick['abbreviation'];
                self::$assignedNames[$blockId][] = $pick['first_name'];
            } else {
                $displayName = $msg['archetype_name'] ?? 'Usuário';
            }

            $seed = $displayName . $archetypeId;
            return [$displayName, avatarUrl($seed), $seed, $archetypeId];
        }

        return ['Usuário', avatarUrl('default'), 'default', null];
    }

    private static function startPendingBlocks(int $roomId): void {
        DB::query(
            "UPDATE blocks SET status = 'running'
             WHERE room_id = ? AND status = 'pending'
             AND (start_at IS NULL OR start_at <= NOW())",
            [$roomId]
        );
    }

    public static function getMessagesSince(int $roomId, int $lastId = 0, int $limit = 50): array {
        return DB::fetchAll(
            'SELECT
                rm.id,
                rm.content,
                rm.message_type,
                rm.posted_at,
                rm.reply_to_room_msg_id,
                rm.display_name             as bot_name,
                rm.avatar_url,
                rm.avatar_seed,
                rm.archetype_id,
                COALESCE(a.name, \'\')      as archetype_name,
                COALESCE(a.avatar_seed, rm.avatar_seed) as avatar_seed,
                bl.name                     as block_name
             FROM room_messages rm
             LEFT JOIN archetypes a  ON a.id  = rm.archetype_id
             JOIN  blocks         bl ON bl.id = rm.block_id
             WHERE rm.room_id = ? AND rm.id > ?
             ORDER BY rm.posted_at ASC, rm.id ASC
             LIMIT ?',
            [$roomId, $lastId, $limit]
        );
    }

    public static function getRecentMessages(int $roomId, int $limit = 80): array {
        $rows = DB::fetchAll(
            'SELECT
                rm.id,
                rm.content,
                rm.message_type,
                rm.posted_at,
                rm.reply_to_room_msg_id,
                rm.display_name             as bot_name,
                rm.avatar_url,
                rm.avatar_seed,
                rm.archetype_id,
                COALESCE(a.name, \'\')      as archetype_name,
                COALESCE(a.avatar_seed, rm.avatar_seed) as avatar_seed,
                bl.name                     as block_name
             FROM room_messages rm
             LEFT JOIN archetypes a  ON a.id  = rm.archetype_id
             JOIN  blocks         bl ON bl.id = rm.block_id
             WHERE rm.room_id = ?
             ORDER BY rm.posted_at DESC, rm.id DESC
             LIMIT ?',
            [$roomId, $limit]
        );
        return array_reverse($rows);
    }

    public static function getRoomStats(int $roomId): array {
        $totalMessages = DB::fetch('SELECT COUNT(*) as total FROM room_messages WHERE room_id = ?', [$roomId]);
        $onlineUsers   = DB::fetch(
            'SELECT COUNT(DISTINCT display_name) as total FROM room_messages
             WHERE room_id = ? AND posted_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)',
            [$roomId]
        );
        $activeBlocks  = DB::fetch(
            "SELECT COUNT(*) as c FROM blocks WHERE room_id = ? AND status = 'running'",
            [$roomId]
        );

        $seed      = crc32(date('Ymd') . $roomId);
        $fakeExtra = 47 + abs($seed) % 266;

        return [
            'total_messages' => (int)($totalMessages['total'] ?? 0),
            'online_count'   => (int)($onlineUsers['total'] ?? 0) + $fakeExtra,
            'active_blocks'  => (int)($activeBlocks['c'] ?? 0),
        ];
    }
}
