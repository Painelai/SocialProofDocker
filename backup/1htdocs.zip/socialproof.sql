-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 03/03/2026 às 00:55
-- Versão do servidor: 5.7.34
-- Versão do PHP: 8.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `socialproof`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `archetypes`
--

CREATE TABLE `archetypes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `speaking_style` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `vocabulary_examples` text COLLATE utf8mb4_unicode_ci,
  `typo_rate` tinyint(4) DEFAULT '10',
  `emoji_rate` tinyint(4) DEFAULT '20',
  `response_delay_min` int(11) DEFAULT '3',
  `response_delay_max` int(11) DEFAULT '25',
  `avatar_seed` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `archetypes`
--

INSERT INTO `archetypes` (`id`, `name`, `description`, `speaking_style`, `vocabulary_examples`, `typo_rate`, `emoji_rate`, `response_delay_min`, `response_delay_max`, `avatar_seed`, `created_at`) VALUES
(1, 'Mae de Familia', 'Mulher de 35-50 anos, pratica, carinhosa', 'Fala de forma carinhosa e pratica. Usa gente, meninas. Conta experiencias reais com filhos e marido.', 'Gente, to adorando! / meninas me ajudem / fiz pra toda familia', 15, 35, 5, 30, 'mae1', '2026-03-01 13:29:07'),
(2, 'Nerd Fitness', 'Homem de 25-35 anos, obcecado com dados e macros', 'Fala com precisao cientifica. Cita estudos. Gosta de numeros e percentuais.', 'De acordo com um estudo / meu percentual de gordura / a ciencia mostra que', 5, 10, 8, 40, 'nerd1', '2026-03-01 13:29:07'),
(3, 'Mano da Quebrada', 'Jovem de 18-28 anos, girias, informal, entusiasmado', 'Usa mano, cara, demais. Frases curtas. Muitos pontos de exclamacao.', 'mano que resultado!! / cara to chocado / funcionou demais', 25, 45, 2, 15, 'mano1', '2026-03-01 13:29:07'),
(4, 'Nutricionista', 'Profissional da saude, 30-45 anos, didatica', 'Linguagem tecnica mas acessivel. Cuida para nao dar diagnostico.', 'Do ponto de vista nutricional / as evidencias indicam / consulte um profissional', 3, 15, 10, 45, 'nutri1', '2026-03-01 13:29:07'),
(5, 'Vendedor de Rua', 'Pessoa animada, persuasiva, 28-45 anos', 'Entusiasta, muitas exclamacoes. Sempre descobriu o segredo de algo.', 'Descobri o segredo! / vale demais a pena / to te contando isso porque', 20, 40, 3, 20, 'vend1', '2026-03-01 13:29:07'),
(6, 'Advogado', 'Profissional exigente, cetico, 35-50 anos', 'Questiona antes de aceitar. Analitico. Usa todavia, entretanto, cabe ressaltar.', 'Quais sao as evidencias? / cabe ressaltar que / todavia os resultados mostram', 5, 5, 15, 60, 'adv1', '2026-03-01 13:29:07');

-- --------------------------------------------------------

--
-- Estrutura para tabela `blocks`
--

CREATE TABLE `blocks` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','running','paused','done') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `start_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `loop_infinite` tinyint(4) DEFAULT '0',
  `is_tips_block` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `blocks`
--

INSERT INTO `blocks` (`id`, `room_id`, `name`, `topic`, `status`, `start_at`, `created_at`, `loop_infinite`, `is_tips_block`) VALUES
(1, 1, '', '', 'running', NULL, '2026-03-01 13:29:08', 1, 1),
(2, 1, 'Resultados e Transformações', 'Pessoas compartilhando quanto emagreceram, como se sentem, fotos e mudanças percebidas', 'done', NULL, '2026-03-01 13:29:08', 0, 0),
(3, 1, 'Dúvidas e Objeções', 'Perguntas sobre custo, dificuldade, metabolismo lento, se funciona para homens, se precisa de academia', 'done', NULL, '2026-03-01 13:29:08', 0, 0),
(4, 1, 'Egípcio vs Outras Dietas', 'Comparação com low carb, jejum intermitente, dieta mediterrânea. Por que o egípcio é diferente', 'done', NULL, '2026-03-01 13:29:08', 0, 0),
(5, 1, 'Dicas do Dia a Dia', 'Receitas fáceis, o que comer no café da manhã, como aplicar o protocolo na correria, substituições práticas', 'done', NULL, '2026-03-01 13:29:08', 0, 0),
(6, 1, 'Valeu o Investimento?', 'Pessoas falando sobre o preço, se vale a pena, comparando com o que gastavam antes em outros métodos', 'done', NULL, '2026-03-01 13:29:08', 0, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `bots`
--

CREATE TABLE `bots` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `archetype_id` int(11) NOT NULL,
  `gender` enum('M','F','N') COLLATE utf8mb4_unicode_ci DEFAULT 'M',
  `avatar_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(4) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `bots`
--

INSERT INTO `bots` (`id`, `name`, `archetype_id`, `gender`, `avatar_url`, `active`, `created_at`) VALUES
(1, 'James', 4, 'M', NULL, 1, '2026-03-01 13:58:26'),
(2, 'Jobson', 3, 'M', NULL, 1, '2026-03-01 13:58:52');

-- --------------------------------------------------------

--
-- Estrutura para tabela `name_pool`
--

CREATE TABLE `name_pool` (
  `id` int(11) NOT NULL,
  `first_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abbreviation` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `archetype_id` int(11) NOT NULL,
  `gender` enum('M','F','N') COLLATE utf8mb4_unicode_ci DEFAULT 'M',
  `active` tinyint(4) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `name_pool`
--

INSERT INTO `name_pool` (`id`, `first_name`, `abbreviation`, `archetype_id`, `gender`, `active`, `created_at`) VALUES
(1, 'Ana', 'C.', 1, 'F', 1, '2026-03-01 13:29:08'),
(2, 'Maria', 'L.', 1, 'F', 1, '2026-03-01 13:29:08'),
(3, 'Sandra', 'R.', 1, 'F', 1, '2026-03-01 13:29:08'),
(4, 'Fernanda', 'M.', 1, 'F', 1, '2026-03-01 13:29:08'),
(5, 'Claudia', 'P.', 1, 'F', 1, '2026-03-01 13:29:08'),
(6, 'Rosana', 'S.', 1, 'F', 1, '2026-03-01 13:29:08'),
(7, 'Patricia', 'A.', 1, 'F', 1, '2026-03-01 13:29:08'),
(8, 'Simone', 'B.', 1, 'F', 1, '2026-03-01 13:29:08'),
(9, 'Juliana', 'T.', 1, 'F', 1, '2026-03-01 13:29:08'),
(10, 'Adriana', 'F.', 1, 'F', 1, '2026-03-01 13:29:08'),
(11, 'Cristina', 'V.', 1, 'F', 1, '2026-03-01 13:29:08'),
(12, 'Renata', 'G.', 1, 'F', 1, '2026-03-01 13:29:08'),
(13, 'Vanessa', 'N.', 1, 'F', 1, '2026-03-01 13:29:08'),
(14, 'Luciana', 'D.', 1, 'F', 1, '2026-03-01 13:29:08'),
(15, 'Marcia', 'O.', 1, 'F', 1, '2026-03-01 13:29:08'),
(16, 'Tatiana', 'E.', 1, 'F', 1, '2026-03-01 13:29:08'),
(17, 'Debora', 'K.', 1, 'F', 1, '2026-03-01 13:29:08'),
(18, 'Eliana', 'H.', 1, 'F', 1, '2026-03-01 13:29:08'),
(19, 'Vera', 'J.', 1, 'F', 1, '2026-03-01 13:29:08'),
(20, 'Sueli', 'Q.', 1, 'F', 1, '2026-03-01 13:29:08'),
(21, 'Iracema', 'U.', 1, 'F', 1, '2026-03-01 13:29:08'),
(22, 'Fatima', 'X.', 1, 'F', 1, '2026-03-01 13:29:08'),
(23, 'Helena', 'Z.', 1, 'F', 1, '2026-03-01 13:29:08'),
(24, 'Beatriz', 'W.', 1, 'F', 1, '2026-03-01 13:29:08'),
(25, 'Lidia', 'Y.', 1, 'F', 1, '2026-03-01 13:29:08'),
(26, 'Celia', 'I.', 1, 'F', 1, '2026-03-01 13:29:08'),
(27, 'Edna', 'C.', 1, 'F', 1, '2026-03-01 13:29:08'),
(28, 'Neide', 'L.', 1, 'F', 1, '2026-03-01 13:29:08'),
(29, 'Zilda', 'M.', 1, 'F', 1, '2026-03-01 13:29:08'),
(30, 'Aparecida', 'R.', 1, 'F', 1, '2026-03-01 13:29:08'),
(31, 'Rafael', 'M.', 2, 'M', 1, '2026-03-01 13:29:08'),
(32, 'Bruno', 'T.', 2, 'M', 1, '2026-03-01 13:29:08'),
(33, 'Felipe', 'A.', 2, 'M', 1, '2026-03-01 13:29:08'),
(34, 'Thiago', 'R.', 2, 'M', 1, '2026-03-01 13:29:08'),
(35, 'Rodrigo', 'S.', 2, 'M', 1, '2026-03-01 13:29:08'),
(36, 'Gustavo', 'L.', 2, 'M', 1, '2026-03-01 13:29:08'),
(37, 'Leonardo', 'B.', 2, 'M', 1, '2026-03-01 13:29:08'),
(38, 'Eduardo', 'C.', 2, 'M', 1, '2026-03-01 13:29:08'),
(39, 'Marcelo', 'F.', 2, 'M', 1, '2026-03-01 13:29:08'),
(40, 'Henrique', 'D.', 2, 'M', 1, '2026-03-01 13:29:08'),
(41, 'Vinicius', 'P.', 2, 'M', 1, '2026-03-01 13:29:08'),
(42, 'Matheus', 'G.', 2, 'M', 1, '2026-03-01 13:29:08'),
(43, 'Lucas', 'N.', 2, 'M', 1, '2026-03-01 13:29:08'),
(44, 'Daniel', 'O.', 2, 'M', 1, '2026-03-01 13:29:08'),
(45, 'Pedro', 'V.', 2, 'M', 1, '2026-03-01 13:29:08'),
(46, 'Andre', 'E.', 2, 'M', 1, '2026-03-01 13:29:08'),
(47, 'Caio', 'K.', 2, 'M', 1, '2026-03-01 13:29:08'),
(48, 'Diego', 'H.', 2, 'M', 1, '2026-03-01 13:29:08'),
(49, 'Fabio', 'J.', 2, 'M', 1, '2026-03-01 13:29:08'),
(50, 'Sergio', 'Q.', 2, 'M', 1, '2026-03-01 13:29:08'),
(51, 'Marcos', 'U.', 2, 'M', 1, '2026-03-01 13:29:08'),
(52, 'Paulo', 'X.', 2, 'M', 1, '2026-03-01 13:29:08'),
(53, 'Roberto', 'Z.', 2, 'M', 1, '2026-03-01 13:29:08'),
(54, 'Carlos', 'W.', 2, 'M', 1, '2026-03-01 13:29:08'),
(55, 'Jorge', 'Y.', 2, 'M', 1, '2026-03-01 13:29:08'),
(56, 'Renato', 'I.', 2, 'M', 1, '2026-03-01 13:29:08'),
(57, 'Leandro', 'C.', 2, 'M', 1, '2026-03-01 13:29:08'),
(58, 'Wagner', 'L.', 2, 'M', 1, '2026-03-01 13:29:08'),
(59, 'Cesar', 'M.', 2, 'M', 1, '2026-03-01 13:29:08'),
(60, 'Ivan', 'R.', 2, 'M', 1, '2026-03-01 13:29:08'),
(61, 'Gabriel', 'S.', 3, 'M', 1, '2026-03-01 13:29:08'),
(62, 'Mateus', 'L.', 3, 'M', 1, '2026-03-01 13:29:08'),
(63, 'Kaique', 'R.', 3, 'M', 1, '2026-03-01 13:29:08'),
(64, 'Wesley', 'M.', 3, 'M', 1, '2026-03-01 13:29:08'),
(65, 'Edson', 'T.', 3, 'M', 1, '2026-03-01 13:29:08'),
(66, 'Renan', 'A.', 3, 'M', 1, '2026-03-01 13:29:08'),
(67, 'Murilo', 'B.', 3, 'M', 1, '2026-03-01 13:29:08'),
(68, 'Yuri', 'C.', 3, 'M', 1, '2026-03-01 13:29:08'),
(69, 'Kaua', 'F.', 3, 'M', 1, '2026-03-01 13:29:08'),
(70, 'Elias', 'D.', 3, 'M', 1, '2026-03-01 13:29:08'),
(71, 'Wendel', 'P.', 3, 'M', 1, '2026-03-01 13:29:08'),
(72, 'Tiago', 'G.', 3, 'M', 1, '2026-03-01 13:29:08'),
(73, 'Jonatas', 'N.', 3, 'M', 1, '2026-03-01 13:29:08'),
(74, 'Rogerio', 'O.', 3, 'M', 1, '2026-03-01 13:29:08'),
(75, 'Nilson', 'V.', 3, 'M', 1, '2026-03-01 13:29:08'),
(76, 'Davi', 'E.', 3, 'M', 1, '2026-03-01 13:29:08'),
(77, 'Samuel', 'K.', 3, 'M', 1, '2026-03-01 13:29:08'),
(78, 'Jhonatan', 'H.', 3, 'M', 1, '2026-03-01 13:29:08'),
(79, 'Willian', 'J.', 3, 'M', 1, '2026-03-01 13:29:08'),
(80, 'Anderson', 'Q.', 3, 'M', 1, '2026-03-01 13:29:08'),
(81, 'Cristian', 'U.', 3, 'M', 1, '2026-03-01 13:29:08'),
(82, 'Kleber', 'X.', 3, 'M', 1, '2026-03-01 13:29:08'),
(83, 'Denilson', 'Z.', 3, 'M', 1, '2026-03-01 13:29:08'),
(84, 'Emerson', 'W.', 3, 'M', 1, '2026-03-01 13:29:08'),
(85, 'Flavio', 'Y.', 3, 'M', 1, '2026-03-01 13:29:08'),
(86, 'Gerson', 'I.', 3, 'M', 1, '2026-03-01 13:29:08'),
(87, 'Hudson', 'C.', 3, 'M', 1, '2026-03-01 13:29:08'),
(88, 'Italo', 'L.', 3, 'M', 1, '2026-03-01 13:29:08'),
(89, 'Jadson', 'M.', 3, 'M', 1, '2026-03-01 13:29:08'),
(90, 'Kelvin', 'R.', 3, 'M', 1, '2026-03-01 13:29:08'),
(91, 'Camila', 'A.', 4, 'F', 1, '2026-03-01 13:29:08'),
(92, 'Priscila', 'B.', 4, 'F', 1, '2026-03-01 13:29:08'),
(93, 'Natalia', 'C.', 4, 'F', 1, '2026-03-01 13:29:08'),
(94, 'Isabela', 'D.', 4, 'F', 1, '2026-03-01 13:29:08'),
(95, 'Larissa', 'E.', 4, 'F', 1, '2026-03-01 13:29:08'),
(96, 'Aline', 'F.', 4, 'F', 1, '2026-03-01 13:29:08'),
(97, 'Amanda', 'G.', 4, 'F', 1, '2026-03-01 13:29:08'),
(98, 'Carolina', 'H.', 4, 'F', 1, '2026-03-01 13:29:08'),
(99, 'Leticia', 'I.', 4, 'F', 1, '2026-03-01 13:29:08'),
(100, 'Viviane', 'J.', 4, 'F', 1, '2026-03-01 13:29:08'),
(101, 'Daniela', 'K.', 4, 'F', 1, '2026-03-01 13:29:08'),
(102, 'Gabriela', 'L.', 4, 'F', 1, '2026-03-01 13:29:08'),
(103, 'Mariana', 'M.', 4, 'F', 1, '2026-03-01 13:29:08'),
(104, 'Rafaela', 'N.', 4, 'F', 1, '2026-03-01 13:29:08'),
(105, 'Bruna', 'O.', 4, 'F', 1, '2026-03-01 13:29:08'),
(106, 'Alessandra', 'P.', 4, 'F', 1, '2026-03-01 13:29:08'),
(107, 'Flavia', 'Q.', 4, 'F', 1, '2026-03-01 13:29:08'),
(108, 'Gisele', 'R.', 4, 'F', 1, '2026-03-01 13:29:08'),
(109, 'Hosana', 'S.', 4, 'F', 1, '2026-03-01 13:29:08'),
(110, 'Ingrid', 'T.', 4, 'F', 1, '2026-03-01 13:29:08'),
(111, 'Jessica', 'U.', 4, 'F', 1, '2026-03-01 13:29:08'),
(112, 'Karina', 'V.', 4, 'F', 1, '2026-03-01 13:29:08'),
(113, 'Lorena', 'X.', 4, 'F', 1, '2026-03-01 13:29:08'),
(114, 'Monica', 'Z.', 4, 'F', 1, '2026-03-01 13:29:08'),
(115, 'Nathalia', 'W.', 4, 'F', 1, '2026-03-01 13:29:08'),
(116, 'Olivia', 'Y.', 4, 'F', 1, '2026-03-01 13:29:08'),
(117, 'Paula', 'I.', 4, 'F', 1, '2026-03-01 13:29:08'),
(118, 'Quenia', 'C.', 4, 'F', 1, '2026-03-01 13:29:08'),
(119, 'Roberta', 'L.', 4, 'F', 1, '2026-03-01 13:29:08'),
(120, 'Silvia', 'M.', 4, 'F', 1, '2026-03-01 13:29:08'),
(121, 'Joao', 'B.', 5, 'M', 1, '2026-03-01 13:29:08'),
(122, 'Jose', 'C.', 5, 'M', 1, '2026-03-01 13:29:08'),
(123, 'Antonio', 'D.', 5, 'M', 1, '2026-03-01 13:29:08'),
(124, 'Francisco', 'E.', 5, 'M', 1, '2026-03-01 13:29:08'),
(125, 'Luis', 'F.', 5, 'M', 1, '2026-03-01 13:29:08'),
(126, 'Raimundo', 'G.', 5, 'M', 1, '2026-03-01 13:29:08'),
(127, 'Manoel', 'H.', 5, 'M', 1, '2026-03-01 13:29:08'),
(128, 'Gilberto', 'I.', 5, 'M', 1, '2026-03-01 13:29:08'),
(129, 'Valdecir', 'J.', 5, 'M', 1, '2026-03-01 13:29:08'),
(130, 'Sebastiao', 'K.', 5, 'M', 1, '2026-03-01 13:29:08'),
(131, 'Benedito', 'L.', 5, 'M', 1, '2026-03-01 13:29:08'),
(132, 'Cicero', 'M.', 5, 'M', 1, '2026-03-01 13:29:08'),
(133, 'Erivaldo', 'N.', 5, 'M', 1, '2026-03-01 13:29:08'),
(134, 'Geraldo', 'O.', 5, 'M', 1, '2026-03-01 13:29:08'),
(135, 'Hilario', 'P.', 5, 'M', 1, '2026-03-01 13:29:08'),
(136, 'Inacio', 'Q.', 5, 'M', 1, '2026-03-01 13:29:08'),
(137, 'Jailson', 'R.', 5, 'M', 1, '2026-03-01 13:29:08'),
(138, 'Lacerda', 'S.', 5, 'M', 1, '2026-03-01 13:29:08'),
(139, 'Marcio', 'T.', 5, 'M', 1, '2026-03-01 13:29:08'),
(140, 'Nivaldo', 'U.', 5, 'M', 1, '2026-03-01 13:29:08'),
(141, 'Osmar', 'V.', 5, 'M', 1, '2026-03-01 13:29:08'),
(142, 'Palmiro', 'X.', 5, 'M', 1, '2026-03-01 13:29:08'),
(143, 'Quirino', 'Z.', 5, 'M', 1, '2026-03-01 13:29:08'),
(144, 'Romulo', 'W.', 5, 'M', 1, '2026-03-01 13:29:08'),
(145, 'Salomao', 'Y.', 5, 'M', 1, '2026-03-01 13:29:08'),
(146, 'Tarcisio', 'I.', 5, 'M', 1, '2026-03-01 13:29:08'),
(147, 'Ubaldo', 'C.', 5, 'M', 1, '2026-03-01 13:29:08'),
(148, 'Valmir', 'L.', 5, 'M', 1, '2026-03-01 13:29:08'),
(149, 'Waldemar', 'M.', 5, 'M', 1, '2026-03-01 13:29:08'),
(150, 'Xisto', 'R.', 5, 'M', 1, '2026-03-01 13:29:08'),
(151, 'Ricardo', 'A.', 6, 'M', 1, '2026-03-01 13:29:08'),
(152, 'Alexandre', 'B.', 6, 'M', 1, '2026-03-01 13:29:08'),
(153, 'Augusto', 'C.', 6, 'M', 1, '2026-03-01 13:29:08'),
(154, 'Claudio', 'D.', 6, 'M', 1, '2026-03-01 13:29:08'),
(155, 'Edgard', 'E.', 6, 'M', 1, '2026-03-01 13:29:08'),
(156, 'Fernando', 'F.', 6, 'M', 1, '2026-03-01 13:29:08'),
(157, 'Gregorio', 'G.', 6, 'M', 1, '2026-03-01 13:29:08'),
(158, 'Herbert', 'H.', 6, 'M', 1, '2026-03-01 13:29:08'),
(159, 'Isaias', 'I.', 6, 'M', 1, '2026-03-01 13:29:08'),
(160, 'Jeronimo', 'J.', 6, 'M', 1, '2026-03-01 13:29:08'),
(161, 'Kalil', 'K.', 6, 'M', 1, '2026-03-01 13:29:08'),
(162, 'Licinio', 'L.', 6, 'M', 1, '2026-03-01 13:29:08'),
(163, 'Mauricio', 'M.', 6, 'M', 1, '2026-03-01 13:29:08'),
(164, 'Norberto', 'N.', 6, 'M', 1, '2026-03-01 13:29:08'),
(165, 'Octavio', 'O.', 6, 'M', 1, '2026-03-01 13:29:08'),
(166, 'Pompilio', 'P.', 6, 'M', 1, '2026-03-01 13:29:08'),
(167, 'Quintino', 'Q.', 6, 'M', 1, '2026-03-01 13:29:08'),
(168, 'Reinaldo', 'R.', 6, 'M', 1, '2026-03-01 13:29:08'),
(169, 'Silvano', 'S.', 6, 'M', 1, '2026-03-01 13:29:08'),
(170, 'Teodoro', 'T.', 6, 'M', 1, '2026-03-01 13:29:08'),
(171, 'Ulisses', 'U.', 6, 'M', 1, '2026-03-01 13:29:08'),
(172, 'Valdemar', 'V.', 6, 'M', 1, '2026-03-01 13:29:08'),
(173, 'Waldir', 'X.', 6, 'M', 1, '2026-03-01 13:29:08'),
(174, 'Xenofonte', 'Z.', 6, 'M', 1, '2026-03-01 13:29:08'),
(175, 'Yago', 'W.', 6, 'M', 1, '2026-03-01 13:29:08'),
(176, 'Zacarias', 'Y.', 6, 'M', 1, '2026-03-01 13:29:08'),
(177, 'Albano', 'I.', 6, 'M', 1, '2026-03-01 13:29:08'),
(178, 'Baldoino', 'C.', 6, 'M', 1, '2026-03-01 13:29:08'),
(179, 'Calixto', 'L.', 6, 'M', 1, '2026-03-01 13:29:08'),
(180, 'Daltro', 'M.', 6, 'M', 1, '2026-03-01 13:29:08');

-- --------------------------------------------------------

--
-- Estrutura para tabela `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','paused','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `avatar_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produto_nome` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nome do produto como aparece na página de vendas',
  `produto_nicho` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nicho: dietas, renda_extra, relacionamento, etc.',
  `produto_mecanismo` text COLLATE utf8mb4_unicode_ci COMMENT 'O que faz esse produto diferente — o por que funciona',
  `produto_publico` text COLLATE utf8mb4_unicode_ci COMMENT 'Quem compra: idade, gênero, situação de vida',
  `resultado_minimo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Menor resultado comum. Ex: 3kg em 3 semanas',
  `resultado_medio` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Resultado que a maioria alcança. Ex: 7kg em 30 dias',
  `resultado_maximo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Melhor caso relatado. Ex: 15kg em 60 dias',
  `beneficios_secundarios` text COLLATE utf8mb4_unicode_ci COMMENT 'Efeitos além do principal. Ex: mais disposição, menos inchaço',
  `primeiro_resultado_em` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Quando sente diferença. Ex: entre 3 e 7 dias',
  `oferta_preco` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Valor exato. Ex: R$147',
  `oferta_acesso` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tipo: vitalício, assinatura, curso com prazo',
  `oferta_garantia` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Ex: 30 dias, reembolso total sem perguntas',
  `objecoes` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON array de objeções',
  `quebras_objecao` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON array paralelo com as quebras de cada objeção',
  `nivel_ceticismo` enum('baixo','medio','alto') COLLATE utf8mb4_unicode_ci DEFAULT 'medio',
  `intensidade_prova` enum('sutil','moderada','intensa') COLLATE utf8mb4_unicode_ci DEFAULT 'moderada',
  `arquetipos_ativos` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON array de archetype IDs ativos para essa sala',
  `arquetipos_cetico_id` int(11) DEFAULT NULL COMMENT 'ID do arquétipo que representa o cético',
  `arquetipos_ancora_id` int(11) DEFAULT NULL COMMENT 'ID do arquétipo âncora',
  `campos_ativos` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON array com nomes dos campos ativados pelo usuário'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `slug`, `description`, `status`, `created_at`, `updated_at`, `avatar_url`, `produto_nome`, `produto_nicho`, `produto_mecanismo`, `produto_publico`, `resultado_minimo`, `resultado_medio`, `resultado_maximo`, `beneficios_secundarios`, `primeiro_resultado_em`, `oferta_preco`, `oferta_acesso`, `oferta_garantia`, `objecoes`, `quebras_objecao`, `nivel_ceticismo`, `intensidade_prova`, `arquetipos_ativos`, `arquetipos_cetico_id`, `arquetipos_ancora_id`, `campos_ativos`) VALUES
(1, 'Dieta Faraônica', 'dieta-faraonica', 'Comunidade oficial do método milenar que emagreceu os faraós', 'active', '2026-03-01 13:29:08', '2026-03-02 15:56:33', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'medio', 'moderada', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `room_analytics`
--

CREATE TABLE `room_analytics` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `visitor_fingerprint` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` enum('view','scroll','click','embed_load') COLLATE utf8mb4_unicode_ci DEFAULT 'view',
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `room_analytics`
--

INSERT INTO `room_analytics` (`id`, `room_id`, `visitor_fingerprint`, `event_type`, `metadata`, `created_at`) VALUES
(1, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772371928108}', '2026-03-01 13:32:08'),
(2, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772372866519}', '2026-03-01 13:47:46'),
(3, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772373026901}', '2026-03-01 13:50:27'),
(4, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772373033480}', '2026-03-01 13:50:33'),
(5, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772373567040}', '2026-03-01 13:59:27'),
(6, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772373569715}', '2026-03-01 13:59:29'),
(7, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772375650401}', '2026-03-01 14:34:10'),
(8, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772375665718}', '2026-03-01 14:34:25'),
(9, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772375670659}', '2026-03-01 14:34:30'),
(10, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772375778353}', '2026-03-01 14:36:18'),
(11, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772375842242}', '2026-03-01 14:37:22'),
(12, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772375871818}', '2026-03-01 14:37:51'),
(13, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772376401383}', '2026-03-01 14:46:41'),
(14, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772376690058}', '2026-03-01 14:51:30'),
(15, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772376933420}', '2026-03-01 14:55:33'),
(16, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772376937197}', '2026-03-01 14:55:37'),
(17, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772377168305}', '2026-03-01 14:59:28'),
(18, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772377175123}', '2026-03-01 14:59:35'),
(19, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772377494223}', '2026-03-01 15:04:54'),
(20, 1, '20062626aef65824', 'scroll', '{\"ts\":1772377494613}', '2026-03-01 15:04:54'),
(21, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772377565036}', '2026-03-01 15:06:05'),
(22, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772377599698}', '2026-03-01 15:06:39'),
(23, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772381016294}', '2026-03-01 16:03:36'),
(24, 1, '20062626aef65824', 'scroll', '{\"ts\":1772381016566}', '2026-03-01 16:03:36'),
(25, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772381059067}', '2026-03-01 16:04:19'),
(26, 1, '20062626aef65824', 'scroll', '{\"ts\":1772381059523}', '2026-03-01 16:04:19'),
(27, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772382422867}', '2026-03-01 16:27:03'),
(28, 1, '20062626aef65824', 'scroll', '{\"ts\":1772382424950}', '2026-03-01 16:27:04'),
(29, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772383008331}', '2026-03-01 16:36:48'),
(30, 1, '20062626aef65824', 'scroll', '{\"ts\":1772383009370}', '2026-03-01 16:36:49'),
(31, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772384266104}', '2026-03-01 16:57:46'),
(32, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772385213404}', '2026-03-01 17:13:33'),
(33, 1, '20062626aef65824', 'scroll', '{\"ts\":1772385213681}', '2026-03-01 17:13:33'),
(34, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772385221206}', '2026-03-01 17:13:41'),
(35, 1, '20062626aef65824', 'scroll', '{\"ts\":1772385221448}', '2026-03-01 17:13:41'),
(36, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772385610832}', '2026-03-01 17:20:11'),
(37, 1, '20062626aef65824', 'scroll', '{\"ts\":1772385611344}', '2026-03-01 17:20:11'),
(38, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772385727263}', '2026-03-01 17:22:07'),
(39, 1, '20062626aef65824', 'scroll', '{\"ts\":1772385727516}', '2026-03-01 17:22:07'),
(40, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772388658378}', '2026-03-01 18:10:58'),
(41, 1, '20062626aef65824', 'scroll', '{\"ts\":1772388660514}', '2026-03-01 18:11:00'),
(42, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772394538044}', '2026-03-01 19:48:58'),
(43, 1, '20062626aef65824', 'scroll', '{\"ts\":1772394538302}', '2026-03-01 19:48:58'),
(44, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772394637248}', '2026-03-01 19:50:37'),
(45, 1, '20062626aef65824', 'scroll', '{\"ts\":1772394637481}', '2026-03-01 19:50:37'),
(46, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772395089213}', '2026-03-01 19:58:09'),
(47, 1, '20062626aef65824', 'scroll', '{\"ts\":1772395089684}', '2026-03-01 19:58:09'),
(48, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772395518565}', '2026-03-01 20:05:18'),
(49, 1, '20062626aef65824', 'scroll', '{\"ts\":1772395518753}', '2026-03-01 20:05:18'),
(50, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772396571741}', '2026-03-01 20:22:51'),
(51, 1, '20062626aef65824', 'scroll', '{\"ts\":1772396572028}', '2026-03-01 20:22:52'),
(52, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772397347200}', '2026-03-01 20:35:47'),
(53, 1, '20062626aef65824', 'scroll', '{\"ts\":1772397347547}', '2026-03-01 20:35:47'),
(54, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772397350506}', '2026-03-01 20:35:50'),
(55, 1, '20062626aef65824', 'scroll', '{\"ts\":1772397350738}', '2026-03-01 20:35:50'),
(56, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772397434945}', '2026-03-01 20:37:15'),
(57, 1, '20062626aef65824', 'scroll', '{\"ts\":1772397435212}', '2026-03-01 20:37:15'),
(58, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772397628185}', '2026-03-01 20:40:28'),
(59, 1, '20062626aef65824', 'scroll', '{\"ts\":1772397628542}', '2026-03-01 20:40:28'),
(60, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772397630486}', '2026-03-01 20:40:30'),
(61, 1, '20062626aef65824', 'scroll', '{\"ts\":1772397630685}', '2026-03-01 20:40:30'),
(62, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772397739113}', '2026-03-01 20:42:19'),
(63, 1, '20062626aef65824', 'scroll', '{\"ts\":1772397739597}', '2026-03-01 20:42:19'),
(64, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772398137898}', '2026-03-01 20:48:57'),
(65, 1, '20062626aef65824', 'scroll', '{\"ts\":1772398138517}', '2026-03-01 20:48:58'),
(66, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772398141269}', '2026-03-01 20:49:01'),
(67, 1, '20062626aef65824', 'scroll', '{\"ts\":1772398141518}', '2026-03-01 20:49:01'),
(68, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772398742680}', '2026-03-01 20:59:02'),
(69, 1, '20062626aef65824', 'scroll', '{\"ts\":1772398743051}', '2026-03-01 20:59:03'),
(70, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772398856867}', '2026-03-01 21:00:57'),
(71, 1, '20062626aef65824', 'scroll', '{\"ts\":1772398857166}', '2026-03-01 21:00:57'),
(72, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772399942093}', '2026-03-01 21:19:02'),
(73, 1, '20062626aef65824', 'scroll', '{\"ts\":1772399942823}', '2026-03-01 21:19:02'),
(74, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772399946933}', '2026-03-01 21:19:06'),
(75, 1, '20062626aef65824', 'scroll', '{\"ts\":1772399947171}', '2026-03-01 21:19:07'),
(76, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772399967766}', '2026-03-01 21:19:27'),
(77, 1, '20062626aef65824', 'scroll', '{\"ts\":1772399967980}', '2026-03-01 21:19:28'),
(78, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772400473075}', '2026-03-01 21:27:53'),
(79, 1, '20062626aef65824', 'scroll', '{\"ts\":1772400473474}', '2026-03-01 21:27:53'),
(80, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772400478375}', '2026-03-01 21:27:58'),
(81, 1, '20062626aef65824', 'scroll', '{\"ts\":1772400478578}', '2026-03-01 21:27:58'),
(82, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772414481838}', '2026-03-02 01:21:22'),
(83, 1, '20062626aef65824', 'scroll', '{\"ts\":1772414482462}', '2026-03-02 01:21:22'),
(84, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772414562397}', '2026-03-02 01:22:42'),
(85, 1, '20062626aef65824', 'scroll', '{\"ts\":1772414562672}', '2026-03-02 01:22:42'),
(86, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772414565973}', '2026-03-02 01:22:46'),
(87, 1, '20062626aef65824', 'scroll', '{\"ts\":1772414566185}', '2026-03-02 01:22:46'),
(88, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772415768472}', '2026-03-02 01:42:48'),
(89, 1, '20062626aef65824', 'scroll', '{\"ts\":1772415768732}', '2026-03-02 01:42:48'),
(90, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772416521913}', '2026-03-02 01:55:22'),
(91, 1, '20062626aef65824', 'scroll', '{\"ts\":1772416522231}', '2026-03-02 01:55:22'),
(92, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772439617720}', '2026-03-02 08:20:17'),
(93, 1, '20062626aef65824', 'scroll', '{\"ts\":1772439617877}', '2026-03-02 08:20:17'),
(94, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772439652478}', '2026-03-02 08:20:52'),
(95, 1, '20062626aef65824', 'scroll', '{\"ts\":1772439652736}', '2026-03-02 08:20:52'),
(96, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772446749514}', '2026-03-02 10:19:09'),
(97, 1, '20062626aef65824', 'scroll', '{\"ts\":1772446750163}', '2026-03-02 10:19:10'),
(98, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772446960872}', '2026-03-02 10:22:40'),
(99, 1, '20062626aef65824', 'scroll', '{\"ts\":1772446961115}', '2026-03-02 10:22:41'),
(100, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772446991423}', '2026-03-02 10:23:11'),
(101, 1, '20062626aef65824', 'scroll', '{\"ts\":1772446991583}', '2026-03-02 10:23:11'),
(102, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772447284501}', '2026-03-02 10:28:04'),
(103, 1, '20062626aef65824', 'scroll', '{\"ts\":1772447284880}', '2026-03-02 10:28:04'),
(104, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772448535442}', '2026-03-02 10:48:55'),
(105, 1, '20062626aef65824', 'scroll', '{\"ts\":1772448535627}', '2026-03-02 10:48:55'),
(106, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772448540686}', '2026-03-02 10:49:00'),
(107, 1, '20062626aef65824', 'scroll', '{\"ts\":1772448540883}', '2026-03-02 10:49:00'),
(108, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772449895139}', '2026-03-02 11:11:35'),
(109, 1, '20062626aef65824', 'scroll', '{\"ts\":1772449895276}', '2026-03-02 11:11:35'),
(110, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772454090820}', '2026-03-02 12:21:31'),
(111, 1, '20062626aef65824', 'scroll', '{\"ts\":1772454090958}', '2026-03-02 12:21:31'),
(112, 1, '20062626aef65824', 'scroll', '{\"ts\":1772465944250}', '2026-03-02 15:39:04'),
(113, 1, '20062626aef65824', 'embed_load', '{\"ts\":1772466450733}', '2026-03-02 15:47:31'),
(114, 1, '20062626aef65824', 'scroll', '{\"ts\":1772466451625}', '2026-03-02 15:47:31');

-- --------------------------------------------------------

--
-- Estrutura para tabela `room_messages`
--

CREATE TABLE `room_messages` (
  `id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `block_id` int(11) NOT NULL,
  `timeline_message_id` int(11) NOT NULL,
  `bot_id` int(11) DEFAULT NULL,
  `archetype_id` int(11) DEFAULT NULL,
  `display_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_seed` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` enum('statement','question','answer','tip','reaction','vacuum_question') COLLATE utf8mb4_unicode_ci DEFAULT 'statement',
  `reply_to_room_msg_id` int(11) DEFAULT NULL,
  `posted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `room_messages`
--

INSERT INTO `room_messages` (`id`, `room_id`, `block_id`, `timeline_message_id`, `bot_id`, `archetype_id`, `display_name`, `avatar_url`, `avatar_seed`, `content`, `message_type`, `reply_to_room_msg_id`, `posted_at`) VALUES
(344, 1, 2, 11, NULL, 1, 'Helena Z.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Helena+Z.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Helena Z.1', 'Meninas, completei 30 dias hoje!! 🎉 Menos 7kg e minhas roupas antigas voltaram a servir. Minha vizinha perguntou o que eu fiz kkkk', 'statement', NULL, '2026-03-02 10:49:00'),
(345, 1, 3, 23, NULL, 3, 'Mateus L.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mateus+L.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Mateus L.3', 'mas precisa comprar aquelas comidas caras de loja de natural não? porque eu não tenho grana pra isso', 'question', NULL, '2026-03-02 10:49:00'),
(346, 1, 4, 35, NULL, 3, 'Wesley M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Wesley+M.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Wesley M.3', 'qual a diferença disso pro low carb? eu tentei low carb e sofri muito', 'question', NULL, '2026-03-02 10:49:00'),
(347, 1, 5, 45, NULL, 4, 'Daniela K.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Daniela+K.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Daniela K.4', 'Dica de ouro que aprendi: café da manhã com proteína muda TUDO. Ovo mexido + fruta antes. Não passo fome até o almoço. Mudou minha vida 😍', 'tip', NULL, '2026-03-02 10:49:00'),
(348, 1, 6, 55, NULL, 3, 'Jhonatan H.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jhonatan+H.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Jhonatan H.3', 'quanto custou o curso de vocês? to em dúvida se compro', 'vacuum_question', NULL, '2026-03-02 10:49:00'),
(350, 1, 2, 12, NULL, 3, 'Flavio Y.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Flavio+Y.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Flavio Y.3', 'CARAAAAI 7kg em 30 dias?? Tô começando hoje mesmo mano', 'reaction', NULL, '2026-03-02 10:49:12'),
(351, 1, 3, 24, NULL, 1, 'Adriana F.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Adriana+F.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Adriana F.1', 'Não meu filho!! Eu faço com arroz integral, ovo, frango, legumes. Tudo de mercado normal. Até gastei MENOS do que antes porque parei de comprar besteira 😄', 'answer', NULL, '2026-03-02 10:49:12'),
(352, 1, 5, 46, NULL, 3, 'Hudson C.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Hudson+C.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Hudson C.3', 'ovo de manhã?? nunca pensei nisso. vou testar amanhã', 'reaction', NULL, '2026-03-02 10:49:12'),
(353, 1, 6, 56, NULL, 1, 'Celia I.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Celia+I.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Celia I.1', 'Eu paguei R$147 no vitalício e já recuperei isso na primeira semana de dieta. Parei de comprar besteira, parei de pedir delivery. No fim SOBROU dinheiro 😂', 'answer', NULL, '2026-03-02 10:49:12'),
(354, 1, 4, 36, NULL, 2, 'Lucas N.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lucas+N.2&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Lucas N.2', 'Diferença fundamental: low carb elimina carboidrato. O método egípcio não elimina nada, ele reorganiza. Você ainda come pão, frutas, cereais. O que muda é quando e com o quê você combina. Por isso é mais sustentável.', 'answer', NULL, '2026-03-02 10:49:24'),
(356, 1, 3, 25, NULL, 5, 'Lacerda S.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lacerda+S.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Lacerda S.5', 'Concordo! Minha lista de compras ficou mais barata e mais simples. O segredo egípcio é a combinação e o horário, não ingredientes exóticos.', 'answer', NULL, '2026-03-02 10:49:30'),
(357, 1, 5, 47, NULL, 2, 'Wagner L.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Wagner+L.2&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Wagner L.2', 'Proteína no café da manhã eleva a saciedade por 4-6 horas. É o que a ciência chama de efeito termogênico da proteína. A gema do ovo especificamente tem colina que potencializa o metabolismo lipídico.', 'statement', NULL, '2026-03-02 10:49:36'),
(358, 1, 6, 57, NULL, 5, 'Nivaldo U.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Nivaldo+U.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Nivaldo U.5', 'Pra ter noção: gastei R$800 numa nutricionista que me deu uma planilha e sumiu. Aqui por R$147 tenho acesso vitalício, comunidade e o método completo. Não tem comparação.', 'statement', NULL, '2026-03-02 10:49:36'),
(359, 1, 2, 13, NULL, 4, 'Gabriela L.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Gabriela+L.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Gabriela L.4', 'Parabéns pelo resultado! 7kg em 30 dias é tecnicamente possível e saudável quando há retenção hídrica inicial envolvida. Importante manter a consistência nos próximos meses.', 'statement', NULL, '2026-03-02 10:49:42'),
(360, 1, 4, 37, NULL, 1, 'Iracema U.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Iracema+U.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Iracema U.1', 'Exatamente! Eu fiz low carb 2 anos. Emagrecia e engordava de volta. Aqui eu como arroz, fruta, nada cortado. E tô emagrecendo mais do que antes 😮', 'answer', NULL, '2026-03-02 10:49:42'),
(362, 1, 2, 14, NULL, 1, 'Tatiana E.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Tatiana+E.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Tatiana E.1', 'É isso mesmo! Nos primeiros dias eu perdi muito líquido que eu nem sabia que tava retendo. Meu inchaço sumiu rapidinho. Depois foi gordura mesmo 😍', 'answer', NULL, '2026-03-02 10:50:00'),
(363, 1, 3, 26, NULL, 6, 'Norberto N.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Norberto+N.6&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Norberto N.6', 'E para quem tem metabolismo lento por questão hormonal? Tenho hipotireoidismo. Há alguma contraindicação?', 'question', NULL, '2026-03-02 10:50:00'),
(364, 1, 6, 58, NULL, 6, 'Jeronimo J.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jeronimo+J.6&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Jeronimo J.6', 'Do ponto de vista custo-benefício: R$147 dividido por 12 meses = R$12,25 por mês. Menos que uma consulta médica, menos que um mês de academia. A relação é evidentemente favorável.', 'statement', NULL, '2026-03-02 10:50:06'),
(365, 1, 4, 38, NULL, 6, 'Valdemar V.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Valdemar+V.6&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Valdemar V.6', 'E em relação ao jejum intermitente? Alguns estudos apontam o jejum como superior para perda de gordura visceral.', 'question', NULL, '2026-03-02 10:50:12'),
(366, 1, 5, 48, NULL, 4, 'Lorena X.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lorena+X.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Lorena X.4', 'Outro hack: comer a salada ANTES da carne. Parece bobagem mas a fibra cria uma barreira no intestino que diminui a absorção de gordura da refeição. Aprendi no protocolo e nunca mais saí dessa.', 'tip', NULL, '2026-03-02 10:50:18'),
(367, 1, 6, 59, NULL, 3, 'Murilo B.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Murilo+B.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Murilo B.3', 'cara colocando assim fica fácil ne kkkk vou comprar hoje', 'reaction', NULL, '2026-03-02 10:50:18'),
(369, 1, 2, 15, NULL, 5, 'Antonio D.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Antonio+D.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Antonio D.5', 'Aqui 11kg em 45 dias gente!! Isso é real!! Falei pro meu marido e ele começou junto comigo semana passada já', 'statement', NULL, '2026-03-02 10:50:24'),
(370, 1, 3, 27, NULL, 4, 'Lorena X.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lorena+X.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Lorena X.4', 'Boa pergunta. Para hipotireoidismo recomendo sempre consultar seu endocrinologista, pois alguns alimentos como a couve crua podem interferir na absorção do iodo. O protocolo em si é compatível mas com algumas adaptações.', 'answer', NULL, '2026-03-02 10:50:30'),
(372, 1, 2, 16, NULL, 2, 'Sergio Q.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sergio+Q.2&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Sergio Q.2', 'Você mediu percentual de gordura ou só peso na balança? Pergunto porque é importante saber se perdeu gordura ou massa magra também.', 'question', NULL, '2026-03-02 10:50:42'),
(373, 1, 4, 39, NULL, 4, 'Gabriela L.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Gabriela+L.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Gabriela L.4', 'Ambos funcionam por mecanismos diferentes. O jejum atua na autofagia e sensibilidade à insulina. O método egípcio atua na combinação e timing alimentar. Para gordura visceral especificamente, os dois têm evidências. A vantagem do egípcio é a adesão, que é muito maior.', 'answer', NULL, '2026-03-02 10:50:42'),
(374, 1, 5, 49, NULL, 4, 'Silvia M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Silvia+M.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Silvia M.4', 'Correto! É o que chamamos de \"sequência alimentar\". Fibra → Proteína → Carboidrato. Isso reduz o pico glicêmico da refeição em até 30% segundo estudos recentes.', 'statement', NULL, '2026-03-02 10:50:42'),
(375, 1, 3, 28, NULL, 6, 'Xenofonte Z.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Xenofonte+Z.6&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Xenofonte Z.6', 'Obrigado pela resposta técnica. Vou conversar com meu médico antes de começar. Aprecio respostas responsáveis aqui.', 'answer', NULL, '2026-03-02 10:50:48'),
(377, 1, 4, 40, NULL, 5, 'Quirino Z.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Quirino+Z.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Quirino Z.5', 'Tentei jejum e quase desmaiava no trabalho!! Com esse método eu como de manhã, almoço e janto. E emagreço. Tô aqui pra contar kkk', 'statement', NULL, '2026-03-02 10:51:00'),
(378, 1, 2, 17, NULL, 5, 'Cicero M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Cicero+M.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Cicero M.5', 'Fiz bioimpedância no mês passado. Percentual de gordura caiu de 38% pra 31%. Massa muscular ficou igual. Fiquei até surpresa!', 'answer', NULL, '2026-03-02 10:51:06'),
(379, 1, 3, 29, NULL, 3, 'Rogerio O.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rogerio+O.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Rogerio O.3', 'e pra homem funciona? parece que é mais coisa de mulher esse grupo kkk', 'question', NULL, '2026-03-02 10:51:12'),
(380, 1, 4, 41, NULL, 3, 'Yuri C.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Yuri+C.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Yuri C.3', 'isso mesmo!! eu também não aguentava ficar sem comer. aqui parece que nem tô de dieta', 'reaction', NULL, '2026-03-02 10:51:12'),
(381, 1, 5, 50, NULL, 1, 'Lidia Y.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Lidia+Y.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Lidia Y.1', 'E no final de semana quando sai pra comer fora? Como faz? Fico com medo de sair da dieta', 'question', NULL, '2026-03-02 10:51:12'),
(382, 1, 2, 18, NULL, 2, 'Caio K.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Caio+K.2&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Caio K.2', 'Excelente! Isso é o ideal. Perda de gordura preservando massa magra. O protocolo está funcionando corretamente no seu caso.', 'reaction', NULL, '2026-03-02 10:51:24'),
(383, 1, 6, 60, NULL, 4, 'Mariana M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mariana+M.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Mariana M.4', 'Não pensa muito não! Tem garantia de 30 dias. Se não gostar pede reembolso. Mas pode ter certeza que você não vai querer 😊', 'tip', NULL, '2026-03-02 10:51:24'),
(384, 1, 3, 30, NULL, 2, 'Cesar M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Cesar+M.2&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Cesar M.2', 'Funciona sim e funciona muito bem. Homens tendem a ter resultados mais rápidos nas primeiras semanas por causa da maior massa muscular e testosterona. Estou aqui e já perdi 9kg em 5 semanas.', 'answer', NULL, '2026-03-02 10:51:30'),
(385, 1, 5, 51, NULL, 5, 'Cicero M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Cicero+M.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Cicero M.5', 'Esse é o melhor de tudo!! Não tem proibição. Só aplica o que você já sabe: pede a salada primeiro, come devagar, bebe água. Nos restaurantes fica até mais fácil porque tem mais opção.', 'answer', NULL, '2026-03-02 10:51:30'),
(386, 1, 3, 31, NULL, 3, 'Gabriel S.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Gabriel+S.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Gabriel S.3', 'boa mano!! isso me animou muito. vou começar essa semana', 'reaction', NULL, '2026-03-02 10:51:43'),
(387, 1, 6, 61, NULL, 2, 'Diego H.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Diego+H.2&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Diego H.2', 'A garantia de 30 dias é fundamental. Significa que o risco financeiro é zero. Você tem 30 dias para testar com dados reais do seu próprio corpo antes de decidir se mantém.', 'statement', NULL, '2026-03-02 10:51:43'),
(388, 1, 4, 42, NULL, 4, 'Jessica U.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jessica+U.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Jessica U.4', 'Esse é o ponto chave: a melhor dieta é a que você consegue manter. Do ponto de vista de sustentabilidade comportamental o método egípcio ganha de qualquer protocolo restritivo.', 'tip', NULL, '2026-03-02 10:51:49'),
(389, 1, 5, 52, NULL, 2, 'Vinicius P.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Vinicius+P.2&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Vinicius P.2', 'Concordo. O protocolo não é dieta de evento, é estilo de vida. Nos fins de semana você pode flexibilizar desde que mantenha a estrutura básica das refeições. A regra 80/20 funciona bem aqui.', 'answer', NULL, '2026-03-02 10:51:54'),
(391, 1, 2, 19, NULL, 6, 'Xenofonte Z.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Xenofonte+Z.6&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Xenofonte Z.6', 'Preciso admitir que era cético. Comecei há 3 semanas apenas para testar. Perdi 4,2kg e minha pressão arterial normalizou segundo meu cardiologista. Os dados me convencem.', 'statement', NULL, '2026-03-02 10:52:01'),
(392, 1, 3, 32, NULL, 1, 'Sandra R.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sandra+R.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Sandra R.1', 'E pra quem tem mais de 50 anos? Minha mãe quer começar também mas tem medo de ser pesado demais', 'question', NULL, '2026-03-02 10:52:07'),
(393, 1, 4, 43, NULL, 1, 'Celia I.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Celia+I.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Celia I.1', 'Minha irmã faz mediterrânea e emagrece bem mas gasta muito em azeite importado e castanhas. Aqui é muito mais barato e funciona igualmente 🙌', 'statement', NULL, '2026-03-02 10:52:07'),
(394, 1, 6, 62, NULL, 5, 'Salomao Y.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Salomao+Y.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Salomao Y.5', 'Eu tava na mesma dúvida. Comprei na promoção pensando que ia pedir reembolso. Não pedi. Aqui tô no segundo mês e já falei pra 4 pessoas comprarem também 😄', 'statement', NULL, '2026-03-02 10:52:07'),
(395, 1, 2, 20, NULL, 1, 'Vanessa N.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Vanessa+N.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Vanessa N.1', 'Que lindo!! Ver até o advogado aqui falando bem já me convence mais ainda 😂❤️', 'reaction', NULL, '2026-03-02 10:52:13'),
(396, 1, 6, 63, NULL, 1, 'Ana C.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ana+C.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Ana C.1', 'Isso mesmo!! Eu virei divulgadora não oficial kkkk todo mundo que pergunta como emagrecí mando o link', 'reaction', NULL, '2026-03-02 10:52:19'),
(398, 1, 3, 33, NULL, 4, 'Silvia M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Silvia+M.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Silvia M.4', 'Para pessoas acima de 50 anos o protocolo é inclusive ainda mais indicado porque foca em alimentos anti-inflamatórios e de fácil digestão. O que muda é a expectativa de velocidade dos resultados, que pode ser um pouco mais lenta. Mas funciona.', 'answer', NULL, '2026-03-02 10:52:31'),
(400, 1, 2, 21, NULL, 3, 'Denilson Z.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Denilson+Z.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Denilson Z.3', 'semana 2 aqui pessoal. menos 3kg mas o que mais sinto é disposição cara. acordo sem aquele cansaço de sempre. isso não tem preço', 'statement', NULL, '2026-03-02 10:52:43'),
(401, 1, 4, 44, NULL, 6, 'Herbert H.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Herbert+H.6&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Herbert H.6', 'Após analisar os relatos aqui e minha própria experiência de 3 semanas, tenho de reconhecer: o método é superior em adesão e resultados práticos. Meu ceticismo inicial foi mal colocado.', 'statement', NULL, '2026-03-02 10:52:43'),
(402, 1, 3, 34, NULL, 5, 'Manoel H.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Manoel+H.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Manoel H.5', 'Minha sogra tem 58 anos e tá no segundo mês! Ela perdeu 8kg e o joelho dela que doía parou de doer. Ela tá radiante gente!!', 'statement', NULL, '2026-03-02 10:52:49'),
(403, 1, 5, 53, NULL, 4, 'Bruna O.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Bruna+O.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Bruna O.4', 'minha dica pra quem trabalha fora: levo marmita com arroz integral + frango grelhado + legumes. faço uma vez na semana e distribuo nos potes. 20 minutos de preparo pro dia inteiro', 'tip', NULL, '2026-03-02 10:52:49'),
(404, 1, 6, 64, NULL, 4, 'Amanda G.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amanda+G.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Amanda G.4', 'Do ponto de vista profissional: o que o protocolo ensina sobre combinação alimentar e ritmo circadiano está alinhado com as últimas diretrizes nutricionais. Recomendo sem restrições.', 'statement', NULL, '2026-03-02 10:52:49'),
(407, 1, 2, 22, NULL, 4, 'Silvia M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Silvia+M.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Silvia M.4', 'Essa disposição que você sente é real e tem explicação: quando você estabiliza a glicemia, o cortisol cai e a energia fica constante ao longo do dia. Continue assim!', 'tip', NULL, '2026-03-02 11:11:41'),
(408, 1, 5, 54, NULL, 1, 'Patricia A.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Patricia+A.1&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Patricia A.1', 'Isso que eu faço também!! Marmita fit egípcia kkk domingo já deixo tudo pronto. Facilita demais! 💪', 'reaction', NULL, '2026-03-02 11:11:41'),
(409, 1, 6, 65, NULL, 3, 'Kelvin R.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kelvin+R.3&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Kelvin R.3', 'fechei!! acabei de comprar. se der resultado eu volto aqui pra contar pra todo mundo 🔥🔥🔥', 'statement', NULL, '2026-03-02 11:11:41'),
(410, 1, 6, 66, NULL, 5, 'Valmir L.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Valmir+L.5&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Valmir L.5', 'Bem vindo!! Você não vai se arrepender. Daqui a 30 dias você volta aqui diferente, pode anotar! 🏆', 'reaction', NULL, '2026-03-02 11:11:53'),
(419, 1, 1, 1, NULL, 4, 'Karina V.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Karina+V.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Karina V.4', 'oi pessoal, acabei de entrar aqui, do que se trata essa dieta faraônica??', 'tip', NULL, '2026-03-02 12:25:43'),
(420, 1, 1, 2, NULL, 4, 'Rafaela N.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rafaela+N.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Rafaela N.4', 'Oi bem vinda!! Essa dieta é baseada nos hábitos alimentares do Antigo Egito. Sem passar fome, sem academia. Eu perdi 6kg no primeiro mês 😊', 'tip', NULL, '2026-03-02 15:39:03'),
(421, 1, 1, 3, NULL, 4, 'Mariana M.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mariana+M.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Mariana M.4', 'Descobri isso há 3 semanas e não consigo parar de falar pra todo mundo! Parece loucura mas funciona demais', 'tip', NULL, '2026-03-02 15:39:21'),
(422, 1, 1, 4, NULL, 4, 'Ingrid T.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ingrid+T.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Ingrid T.4', 'Alguém tem embasamento científico sobre isso? Fico desconfiado de métodos que prometem resultados tão rápidos.', 'tip', NULL, '2026-03-02 15:39:46'),
(423, 1, 1, 5, NULL, 4, 'Camila A.', 'https://api.dicebear.com/7.x/avataaars/svg?seed=Camila+A.4&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf', 'Camila A.4', 'Entendo o ceticismo. O método é baseado em densidade nutricional e combinação de alimentos. Estudos de 2021 publicados no Journal of Nutritional Science corroboram a abordagem. O que muda é a ordem e a combinação, não privação.', 'tip', NULL, '2026-03-02 15:47:36');

-- --------------------------------------------------------

--
-- Estrutura para tabela `room_message_reactions`
--

CREATE TABLE `room_message_reactions` (
  `id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `emoji` varchar(8) NOT NULL,
  `visitor_fp` varchar(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `settings`
--

CREATE TABLE `settings` (
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `settings`
--

INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES
('admin_token', '', '2026-03-01 13:29:07'),
('claude_api_key', '', '2026-03-01 13:29:07'),
('claude_model', 'claude-opus-4-5', '2026-03-01 13:29:07'),
('cron_token', '', '2026-03-01 13:29:07'),
('messages_per_page', '50', '2026-03-01 13:29:07'),
('timezone', 'America/Sao_Paulo', '2026-03-01 13:29:07');

-- --------------------------------------------------------

--
-- Estrutura para tabela `timeline_messages`
--

CREATE TABLE `timeline_messages` (
  `id` int(11) NOT NULL,
  `block_id` int(11) NOT NULL,
  `bot_id` int(11) DEFAULT NULL COMMENT 'Modo clássico: bot fixo',
  `archetype_id` int(11) DEFAULT NULL COMMENT 'Modo pool: sorteia nome do name_pool',
  `resolved_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nome montado ex: Joao M.',
  `message_type` enum('statement','question','answer','tip','reaction','vacuum_question') COLLATE utf8mb4_unicode_ci DEFAULT 'statement',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reply_to_id` int(11) DEFAULT NULL,
  `sequence_order` int(11) NOT NULL,
  `delay_after_prev` int(11) DEFAULT '8',
  `posted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `timeline_messages`
--

INSERT INTO `timeline_messages` (`id`, `block_id`, `bot_id`, `archetype_id`, `resolved_name`, `message_type`, `content`, `reply_to_id`, `sequence_order`, `delay_after_prev`, `posted_at`, `created_at`) VALUES
(1, 1, NULL, 3, NULL, 'vacuum_question', 'oi pessoal, acabei de entrar aqui, do que se trata essa dieta faraônica??', NULL, 1, 5, '2026-03-02 09:25:43', '2026-03-01 13:29:08'),
(2, 1, NULL, 1, NULL, 'answer', 'Oi bem vinda!! Essa dieta é baseada nos hábitos alimentares do Antigo Egito. Sem passar fome, sem academia. Eu perdi 6kg no primeiro mês 😊', NULL, 2, 12, '2026-03-02 12:39:03', '2026-03-01 13:29:08'),
(3, 1, NULL, 5, NULL, 'statement', 'Descobri isso há 3 semanas e não consigo parar de falar pra todo mundo! Parece loucura mas funciona demais', NULL, 3, 18, '2026-03-02 12:39:21', '2026-03-01 13:29:08'),
(4, 1, NULL, 6, NULL, 'question', 'Alguém tem embasamento científico sobre isso? Fico desconfiado de métodos que prometem resultados tão rápidos.', NULL, 4, 25, '2026-03-02 12:39:46', '2026-03-01 13:29:08'),
(5, 1, NULL, 2, NULL, 'answer', 'Entendo o ceticismo. O método é baseado em densidade nutricional e combinação de alimentos. Estudos de 2021 publicados no Journal of Nutritional Science corroboram a abordagem. O que muda é a ordem e a combinação, não privação.', NULL, 5, 20, '2026-03-02 12:47:36', '2026-03-01 13:29:08'),
(6, 1, NULL, 6, NULL, 'reaction', 'Hm, interessante. Vou pesquisar mais. Obrigado pela referência.', NULL, 6, 15, NULL, '2026-03-01 13:29:08'),
(7, 1, NULL, 3, NULL, 'reaction', 'mano eu era igual esse advogado aí, duvidei muito kkkk mas olha, 5kg em 3 semanas aqui 🔥', NULL, 7, 10, NULL, '2026-03-01 13:29:08'),
(8, 1, NULL, 4, NULL, 'tip', 'Gente o que me ajudou muito foi começar devagar. Não tenta mudar tudo de uma vez. Começa pelo café da manhã que já faz diferença 💛', NULL, 8, 22, NULL, '2026-03-01 13:29:08'),
(9, 1, NULL, 4, NULL, 'statement', 'Do ponto de vista nutricional o que essa dieta faz de muito correto é priorizar alimentos de baixo índice glicêmico na primeira refeição. Isso regula a insulina o dia todo.', NULL, 9, 30, NULL, '2026-03-01 13:29:08'),
(10, 1, NULL, 5, NULL, 'reaction', 'Nossa que explicação boa! Eu sentia justamente isso, ficava com fome logo depois de comer e agora não sinto mais isso!', NULL, 10, 12, NULL, '2026-03-01 13:29:08'),
(11, 2, NULL, 1, NULL, 'statement', 'Meninas, completei 30 dias hoje!! 🎉 Menos 7kg e minhas roupas antigas voltaram a servir. Minha vizinha perguntou o que eu fiz kkkk', NULL, 1, 5, '2026-03-02 07:49:00', '2026-03-01 13:29:08'),
(12, 2, NULL, 3, NULL, 'reaction', 'CARAAAAI 7kg em 30 dias?? Tô começando hoje mesmo mano', NULL, 2, 8, '2026-03-02 07:49:12', '2026-03-01 13:29:08'),
(13, 2, NULL, 4, NULL, 'statement', 'Parabéns pelo resultado! 7kg em 30 dias é tecnicamente possível e saudável quando há retenção hídrica inicial envolvida. Importante manter a consistência nos próximos meses.', NULL, 3, 25, '2026-03-02 07:49:42', '2026-03-01 13:29:08'),
(14, 2, NULL, 1, NULL, 'answer', 'É isso mesmo! Nos primeiros dias eu perdi muito líquido que eu nem sabia que tava retendo. Meu inchaço sumiu rapidinho. Depois foi gordura mesmo 😍', NULL, 4, 15, '2026-03-02 07:50:00', '2026-03-01 13:29:08'),
(15, 2, NULL, 5, NULL, 'statement', 'Aqui 11kg em 45 dias gente!! Isso é real!! Falei pro meu marido e ele começou junto comigo semana passada já', NULL, 5, 20, '2026-03-02 07:50:24', '2026-03-01 13:29:08'),
(16, 2, NULL, 2, NULL, 'question', 'Você mediu percentual de gordura ou só peso na balança? Pergunto porque é importante saber se perdeu gordura ou massa magra também.', NULL, 6, 18, '2026-03-02 07:50:42', '2026-03-01 13:29:08'),
(17, 2, NULL, 5, NULL, 'answer', 'Fiz bioimpedância no mês passado. Percentual de gordura caiu de 38% pra 31%. Massa muscular ficou igual. Fiquei até surpresa!', NULL, 7, 22, '2026-03-02 07:51:06', '2026-03-01 13:29:08'),
(18, 2, NULL, 2, NULL, 'reaction', 'Excelente! Isso é o ideal. Perda de gordura preservando massa magra. O protocolo está funcionando corretamente no seu caso.', NULL, 8, 15, '2026-03-02 07:51:24', '2026-03-01 13:29:08'),
(19, 2, NULL, 6, NULL, 'statement', 'Preciso admitir que era cético. Comecei há 3 semanas apenas para testar. Perdi 4,2kg e minha pressão arterial normalizou segundo meu cardiologista. Os dados me convencem.', NULL, 9, 35, '2026-03-02 07:52:01', '2026-03-01 13:29:08'),
(20, 2, NULL, 1, NULL, 'reaction', 'Que lindo!! Ver até o advogado aqui falando bem já me convence mais ainda 😂❤️', NULL, 10, 10, '2026-03-02 07:52:13', '2026-03-01 13:29:08'),
(21, 2, NULL, 3, NULL, 'statement', 'semana 2 aqui pessoal. menos 3kg mas o que mais sinto é disposição cara. acordo sem aquele cansaço de sempre. isso não tem preço', NULL, 11, 25, '2026-03-02 07:52:43', '2026-03-01 13:29:08'),
(22, 2, NULL, 4, NULL, 'tip', 'Essa disposição que você sente é real e tem explicação: quando você estabiliza a glicemia, o cortisol cai e a energia fica constante ao longo do dia. Continue assim!', NULL, 12, 20, '2026-03-02 08:11:41', '2026-03-01 13:29:08'),
(23, 3, NULL, 3, NULL, 'question', 'mas precisa comprar aquelas comidas caras de loja de natural não? porque eu não tenho grana pra isso', NULL, 1, 5, '2026-03-02 07:49:00', '2026-03-01 13:29:08'),
(24, 3, NULL, 1, NULL, 'answer', 'Não meu filho!! Eu faço com arroz integral, ovo, frango, legumes. Tudo de mercado normal. Até gastei MENOS do que antes porque parei de comprar besteira 😄', NULL, 2, 12, '2026-03-02 07:49:12', '2026-03-01 13:29:08'),
(25, 3, NULL, 5, NULL, 'answer', 'Concordo! Minha lista de compras ficou mais barata e mais simples. O segredo egípcio é a combinação e o horário, não ingredientes exóticos.', NULL, 3, 15, '2026-03-02 07:49:30', '2026-03-01 13:29:08'),
(26, 3, NULL, 6, NULL, 'question', 'E para quem tem metabolismo lento por questão hormonal? Tenho hipotireoidismo. Há alguma contraindicação?', NULL, 4, 30, '2026-03-02 07:50:00', '2026-03-01 13:29:08'),
(27, 3, NULL, 4, NULL, 'answer', 'Boa pergunta. Para hipotireoidismo recomendo sempre consultar seu endocrinologista, pois alguns alimentos como a couve crua podem interferir na absorção do iodo. O protocolo em si é compatível mas com algumas adaptações.', NULL, 5, 25, '2026-03-02 07:50:30', '2026-03-01 13:29:08'),
(28, 3, NULL, 6, NULL, 'answer', 'Obrigado pela resposta técnica. Vou conversar com meu médico antes de começar. Aprecio respostas responsáveis aqui.', NULL, 6, 18, '2026-03-02 07:50:48', '2026-03-01 13:29:08'),
(29, 3, NULL, 3, NULL, 'question', 'e pra homem funciona? parece que é mais coisa de mulher esse grupo kkk', NULL, 7, 20, '2026-03-02 07:51:12', '2026-03-01 13:29:08'),
(30, 3, NULL, 2, NULL, 'answer', 'Funciona sim e funciona muito bem. Homens tendem a ter resultados mais rápidos nas primeiras semanas por causa da maior massa muscular e testosterona. Estou aqui e já perdi 9kg em 5 semanas.', NULL, 8, 15, '2026-03-02 07:51:30', '2026-03-01 13:29:08'),
(31, 3, NULL, 3, NULL, 'reaction', 'boa mano!! isso me animou muito. vou começar essa semana', NULL, 9, 8, '2026-03-02 07:51:43', '2026-03-01 13:29:08'),
(32, 3, NULL, 1, NULL, 'question', 'E pra quem tem mais de 50 anos? Minha mãe quer começar também mas tem medo de ser pesado demais', NULL, 10, 22, '2026-03-02 07:52:07', '2026-03-01 13:29:08'),
(33, 3, NULL, 4, NULL, 'answer', 'Para pessoas acima de 50 anos o protocolo é inclusive ainda mais indicado porque foca em alimentos anti-inflamatórios e de fácil digestão. O que muda é a expectativa de velocidade dos resultados, que pode ser um pouco mais lenta. Mas funciona.', NULL, 11, 20, '2026-03-02 07:52:31', '2026-03-01 13:29:08'),
(34, 3, NULL, 5, NULL, 'statement', 'Minha sogra tem 58 anos e tá no segundo mês! Ela perdeu 8kg e o joelho dela que doía parou de doer. Ela tá radiante gente!!', NULL, 12, 18, '2026-03-02 07:52:49', '2026-03-01 13:29:08'),
(35, 4, NULL, 3, NULL, 'question', 'qual a diferença disso pro low carb? eu tentei low carb e sofri muito', NULL, 1, 5, '2026-03-02 07:49:00', '2026-03-01 13:29:08'),
(36, 4, NULL, 2, NULL, 'answer', 'Diferença fundamental: low carb elimina carboidrato. O método egípcio não elimina nada, ele reorganiza. Você ainda come pão, frutas, cereais. O que muda é quando e com o quê você combina. Por isso é mais sustentável.', NULL, 2, 20, '2026-03-02 07:49:24', '2026-03-01 13:29:08'),
(37, 4, NULL, 1, NULL, 'answer', 'Exatamente! Eu fiz low carb 2 anos. Emagrecia e engordava de volta. Aqui eu como arroz, fruta, nada cortado. E tô emagrecendo mais do que antes 😮', NULL, 3, 15, '2026-03-02 07:49:42', '2026-03-01 13:29:08'),
(38, 4, NULL, 6, NULL, 'question', 'E em relação ao jejum intermitente? Alguns estudos apontam o jejum como superior para perda de gordura visceral.', NULL, 4, 30, '2026-03-02 07:50:12', '2026-03-01 13:29:08'),
(39, 4, NULL, 4, NULL, 'answer', 'Ambos funcionam por mecanismos diferentes. O jejum atua na autofagia e sensibilidade à insulina. O método egípcio atua na combinação e timing alimentar. Para gordura visceral especificamente, os dois têm evidências. A vantagem do egípcio é a adesão, que é muito maior.', NULL, 5, 28, '2026-03-02 07:50:42', '2026-03-01 13:29:08'),
(40, 4, NULL, 5, NULL, 'statement', 'Tentei jejum e quase desmaiava no trabalho!! Com esse método eu como de manhã, almoço e janto. E emagreço. Tô aqui pra contar kkk', NULL, 6, 15, '2026-03-02 07:51:00', '2026-03-01 13:29:08'),
(41, 4, NULL, 3, NULL, 'reaction', 'isso mesmo!! eu também não aguentava ficar sem comer. aqui parece que nem tô de dieta', NULL, 7, 10, '2026-03-02 07:51:12', '2026-03-01 13:29:08'),
(42, 4, NULL, 4, NULL, 'tip', 'Esse é o ponto chave: a melhor dieta é a que você consegue manter. Do ponto de vista de sustentabilidade comportamental o método egípcio ganha de qualquer protocolo restritivo.', NULL, 8, 22, '2026-03-02 07:51:49', '2026-03-01 13:29:08'),
(43, 4, NULL, 1, NULL, 'statement', 'Minha irmã faz mediterrânea e emagrece bem mas gasta muito em azeite importado e castanhas. Aqui é muito mais barato e funciona igualmente 🙌', NULL, 9, 18, '2026-03-02 07:52:07', '2026-03-01 13:29:08'),
(44, 4, NULL, 6, NULL, 'statement', 'Após analisar os relatos aqui e minha própria experiência de 3 semanas, tenho de reconhecer: o método é superior em adesão e resultados práticos. Meu ceticismo inicial foi mal colocado.', NULL, 10, 35, '2026-03-02 07:52:43', '2026-03-01 13:29:08'),
(45, 5, NULL, 4, NULL, 'tip', 'Dica de ouro que aprendi: café da manhã com proteína muda TUDO. Ovo mexido + fruta antes. Não passo fome até o almoço. Mudou minha vida 😍', NULL, 1, 5, '2026-03-02 07:49:00', '2026-03-01 13:29:08'),
(46, 5, NULL, 3, NULL, 'reaction', 'ovo de manhã?? nunca pensei nisso. vou testar amanhã', NULL, 2, 10, '2026-03-02 07:49:12', '2026-03-01 13:29:08'),
(47, 5, NULL, 2, NULL, 'statement', 'Proteína no café da manhã eleva a saciedade por 4-6 horas. É o que a ciência chama de efeito termogênico da proteína. A gema do ovo especificamente tem colina que potencializa o metabolismo lipídico.', NULL, 3, 20, '2026-03-02 07:49:36', '2026-03-01 13:29:08'),
(48, 5, NULL, 4, NULL, 'tip', 'Outro hack: comer a salada ANTES da carne. Parece bobagem mas a fibra cria uma barreira no intestino que diminui a absorção de gordura da refeição. Aprendi no protocolo e nunca mais saí dessa.', NULL, 4, 18, '2026-03-02 07:50:18', '2026-03-01 13:29:08'),
(49, 5, NULL, 4, NULL, 'statement', 'Correto! É o que chamamos de \"sequência alimentar\". Fibra → Proteína → Carboidrato. Isso reduz o pico glicêmico da refeição em até 30% segundo estudos recentes.', NULL, 5, 22, '2026-03-02 07:50:42', '2026-03-01 13:29:08'),
(50, 5, NULL, 1, NULL, 'question', 'E no final de semana quando sai pra comer fora? Como faz? Fico com medo de sair da dieta', NULL, 6, 25, '2026-03-02 07:51:12', '2026-03-01 13:29:08'),
(51, 5, NULL, 5, NULL, 'answer', 'Esse é o melhor de tudo!! Não tem proibição. Só aplica o que você já sabe: pede a salada primeiro, come devagar, bebe água. Nos restaurantes fica até mais fácil porque tem mais opção.', NULL, 7, 15, '2026-03-02 07:51:30', '2026-03-01 13:29:08'),
(52, 5, NULL, 2, NULL, 'answer', 'Concordo. O protocolo não é dieta de evento, é estilo de vida. Nos fins de semana você pode flexibilizar desde que mantenha a estrutura básica das refeições. A regra 80/20 funciona bem aqui.', NULL, 8, 20, '2026-03-02 07:51:54', '2026-03-01 13:29:08'),
(53, 5, NULL, 4, NULL, 'tip', 'minha dica pra quem trabalha fora: levo marmita com arroz integral + frango grelhado + legumes. faço uma vez na semana e distribuo nos potes. 20 minutos de preparo pro dia inteiro', NULL, 9, 15, '2026-03-02 07:52:49', '2026-03-01 13:29:08'),
(54, 5, NULL, 1, NULL, 'reaction', 'Isso que eu faço também!! Marmita fit egípcia kkk domingo já deixo tudo pronto. Facilita demais! 💪', NULL, 10, 10, '2026-03-02 08:11:41', '2026-03-01 13:29:08'),
(55, 6, NULL, 3, NULL, 'vacuum_question', 'quanto custou o curso de vocês? to em dúvida se compro', NULL, 1, 5, '2026-03-02 07:49:00', '2026-03-01 13:29:08'),
(56, 6, NULL, 1, NULL, 'answer', 'Eu paguei R$147 no vitalício e já recuperei isso na primeira semana de dieta. Parei de comprar besteira, parei de pedir delivery. No fim SOBROU dinheiro 😂', NULL, 2, 12, '2026-03-02 07:49:12', '2026-03-01 13:29:08'),
(57, 6, NULL, 5, NULL, 'statement', 'Pra ter noção: gastei R$800 numa nutricionista que me deu uma planilha e sumiu. Aqui por R$147 tenho acesso vitalício, comunidade e o método completo. Não tem comparação.', NULL, 3, 20, '2026-03-02 07:49:36', '2026-03-01 13:29:08'),
(58, 6, NULL, 6, NULL, 'statement', 'Do ponto de vista custo-benefício: R$147 dividido por 12 meses = R$12,25 por mês. Menos que uma consulta médica, menos que um mês de academia. A relação é evidentemente favorável.', NULL, 4, 30, '2026-03-02 07:50:06', '2026-03-01 13:29:08'),
(59, 6, NULL, 3, NULL, 'reaction', 'cara colocando assim fica fácil ne kkkk vou comprar hoje', NULL, 5, 10, '2026-03-02 07:50:18', '2026-03-01 13:29:08'),
(60, 6, NULL, 4, NULL, 'tip', 'Não pensa muito não! Tem garantia de 30 dias. Se não gostar pede reembolso. Mas pode ter certeza que você não vai querer 😊', NULL, 6, 15, '2026-03-02 07:51:24', '2026-03-01 13:29:08'),
(61, 6, NULL, 2, NULL, 'statement', 'A garantia de 30 dias é fundamental. Significa que o risco financeiro é zero. Você tem 30 dias para testar com dados reais do seu próprio corpo antes de decidir se mantém.', NULL, 7, 18, '2026-03-02 07:51:43', '2026-03-01 13:29:08'),
(62, 6, NULL, 5, NULL, 'statement', 'Eu tava na mesma dúvida. Comprei na promoção pensando que ia pedir reembolso. Não pedi. Aqui tô no segundo mês e já falei pra 4 pessoas comprarem também 😄', NULL, 8, 22, '2026-03-02 07:52:07', '2026-03-01 13:29:08'),
(63, 6, NULL, 1, NULL, 'reaction', 'Isso mesmo!! Eu virei divulgadora não oficial kkkk todo mundo que pergunta como emagrecí mando o link', NULL, 9, 12, '2026-03-02 07:52:19', '2026-03-01 13:29:08'),
(64, 6, NULL, 4, NULL, 'statement', 'Do ponto de vista profissional: o que o protocolo ensina sobre combinação alimentar e ritmo circadiano está alinhado com as últimas diretrizes nutricionais. Recomendo sem restrições.', NULL, 10, 28, '2026-03-02 07:52:49', '2026-03-01 13:29:08'),
(65, 6, NULL, 3, NULL, 'statement', 'fechei!! acabei de comprar. se der resultado eu volto aqui pra contar pra todo mundo 🔥🔥🔥', NULL, 11, 15, '2026-03-02 08:11:41', '2026-03-01 13:29:08'),
(66, 6, NULL, 5, NULL, 'reaction', 'Bem vindo!! Você não vai se arrepender. Daqui a 30 dias você volta aqui diferente, pode anotar! 🏆', NULL, 12, 10, '2026-03-02 08:11:53', '2026-03-01 13:29:08');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `archetypes`
--
ALTER TABLE `archetypes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`);

--
-- Índices de tabela `bots`
--
ALTER TABLE `bots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `archetype_id` (`archetype_id`);

--
-- Índices de tabela `name_pool`
--
ALTER TABLE `name_pool`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_archetype_gender` (`archetype_id`,`gender`,`active`);

--
-- Índices de tabela `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `arquetipos_cetico_id` (`arquetipos_cetico_id`),
  ADD KEY `arquetipos_ancora_id` (`arquetipos_ancora_id`);

--
-- Índices de tabela `room_analytics`
--
ALTER TABLE `room_analytics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_room_analytics` (`room_id`,`created_at`);

--
-- Índices de tabela `room_messages`
--
ALTER TABLE `room_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `block_id` (`block_id`),
  ADD KEY `idx_room_posted` (`room_id`,`posted_at`);

--
-- Índices de tabela `room_message_reactions`
--
ALTER TABLE `room_message_reactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_react` (`message_id`,`visitor_fp`,`emoji`);

--
-- Índices de tabela `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Índices de tabela `timeline_messages`
--
ALTER TABLE `timeline_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bot_id` (`bot_id`),
  ADD KEY `archetype_id` (`archetype_id`),
  ADD KEY `reply_to_id` (`reply_to_id`),
  ADD KEY `idx_block_sequence` (`block_id`,`sequence_order`),
  ADD KEY `idx_posted` (`posted_at`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `archetypes`
--
ALTER TABLE `archetypes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `bots`
--
ALTER TABLE `bots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `name_pool`
--
ALTER TABLE `name_pool`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT de tabela `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `room_analytics`
--
ALTER TABLE `room_analytics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT de tabela `room_messages`
--
ALTER TABLE `room_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=424;

--
-- AUTO_INCREMENT de tabela `room_message_reactions`
--
ALTER TABLE `room_message_reactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `timeline_messages`
--
ALTER TABLE `timeline_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `blocks`
--
ALTER TABLE `blocks`
  ADD CONSTRAINT `blocks_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `bots`
--
ALTER TABLE `bots`
  ADD CONSTRAINT `bots_ibfk_1` FOREIGN KEY (`archetype_id`) REFERENCES `archetypes` (`id`);

--
-- Restrições para tabelas `name_pool`
--
ALTER TABLE `name_pool`
  ADD CONSTRAINT `name_pool_ibfk_1` FOREIGN KEY (`archetype_id`) REFERENCES `archetypes` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `rooms_ibfk_ancora` FOREIGN KEY (`arquetipos_ancora_id`) REFERENCES `archetypes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `rooms_ibfk_cetico` FOREIGN KEY (`arquetipos_cetico_id`) REFERENCES `archetypes` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `room_messages`
--
ALTER TABLE `room_messages`
  ADD CONSTRAINT `room_messages_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`),
  ADD CONSTRAINT `room_messages_ibfk_2` FOREIGN KEY (`block_id`) REFERENCES `blocks` (`id`);

--
-- Restrições para tabelas `timeline_messages`
--
ALTER TABLE `timeline_messages`
  ADD CONSTRAINT `timeline_messages_ibfk_1` FOREIGN KEY (`block_id`) REFERENCES `blocks` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `timeline_messages_ibfk_2` FOREIGN KEY (`bot_id`) REFERENCES `bots` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `timeline_messages_ibfk_3` FOREIGN KEY (`archetype_id`) REFERENCES `archetypes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `timeline_messages_ibfk_4` FOREIGN KEY (`reply_to_id`) REFERENCES `timeline_messages` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
